# MPP
Fruit\
  Attributes:\
  -id\
  -name\
  -color\
  -quality\
  -expiration date\
  -origin

